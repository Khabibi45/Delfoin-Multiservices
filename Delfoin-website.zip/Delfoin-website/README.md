# Élégance Beauté

Site généré par SiteBuilder AI.

## 🚀 Démarrage Rapide (Docker)

1. Assurez-vous d'avoir Docker installé.
2. Ouvrez un terminal dans ce dossier.
3. Lancez la commande :
   ```bash
   docker-compose up --build
   ```
4. Ouvrez votre navigateur sur [http://localhost:8080](http://localhost:8080)

## 🛠️ Installation Manuelle (PHP)

Copiez le contenu du dossier `public` vers votre racine web.
